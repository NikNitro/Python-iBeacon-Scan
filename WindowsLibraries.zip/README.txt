To use in Windows is necesary install the libraries using this executables.
The sympy library can be founded in https://github.com/sympy/sympy/releases
The mpmath library can be founded in https://code.google.com/archive/p/mpmath/downloads